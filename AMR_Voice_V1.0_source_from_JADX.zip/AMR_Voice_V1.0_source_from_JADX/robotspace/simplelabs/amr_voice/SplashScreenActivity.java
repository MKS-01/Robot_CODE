package robotspace.simplelabs.amr_voice;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;
import android.widget.Toast;

public class SplashScreenActivity extends Activity {
    final SplashScreenActivity SplashScreen;
    private Thread SplashThread;
    BluetoothAdapter bluetoothAdapter;

    /* renamed from: robotspace.simplelabs.amr_voice.SplashScreenActivity.1 */
    class C00281 extends Thread {
        C00281() {
        }

        public void run() {
            while (!SplashScreenActivity.this.bluetoothAdapter.isEnabled()) {
                try {
                    synchronized (this) {
                        wait(5000);
                    }
                } catch (InterruptedException e) {
                } finally {
                    SplashScreenActivity.this.finish();
                    Intent i = new Intent();
                    i.setClass(SplashScreenActivity.this.SplashScreen, VoiceControlActivity.class);
                    SplashScreenActivity.this.startActivity(i);
                }
            }
        }
    }

    public SplashScreenActivity() {
        this.SplashScreen = this;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0027R.layout.activity_splash_screen);
        this.bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (this.bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", 1).show();
            finish();
        }
        if (!this.bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "ENABLING BLUETOOTH !", 1).show();
            this.bluetoothAdapter.enable();
        }
        this.SplashThread = new C00281();
        this.SplashThread.start();
    }

    public void onBackPressed() {
        this.bluetoothAdapter.disable();
        Toast.makeText(this, "DISABLING BLUETOOTH !", 1).show();
        Process.killProcess(Process.myPid());
        finish();
    }
}
