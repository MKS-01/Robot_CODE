package robotspace.simplelabs.amr_voice;

/* renamed from: robotspace.simplelabs.amr_voice.R */
public final class C0027R {

    /* renamed from: robotspace.simplelabs.amr_voice.R.attr */
    public static final class attr {
    }

    /* renamed from: robotspace.simplelabs.amr_voice.R.drawable */
    public static final class drawable {
        public static final int accelerometer = 2130837504;
        public static final int bluetooth = 2130837505;
        public static final int ic_launcher = 2130837506;
        public static final int minidroid = 2130837507;
        public static final int robotspace = 2130837508;
        public static final int simplelabs = 2130837509;
        public static final int siri = 2130837510;
        public static final int splash = 2130837511;
        public static final int splashscreen = 2130837512;
        public static final int voice = 2130837513;
    }

    /* renamed from: robotspace.simplelabs.amr_voice.R.id */
    public static final class id {
        public static final int BluetoothSettings = 2131165205;
        public static final int Scan = 2131165204;
        public static final int app_info = 2131165206;
        public static final int button_scan = 2131165203;
        public static final int edittext1 = 2131165195;
        public static final int edittext2 = 2131165197;
        public static final int imageView1 = 2131165191;
        public static final int imageView2 = 2131165192;
        public static final int new_devices = 2131165202;
        public static final int paired_devices = 2131165200;
        public static final int save_mem1 = 2131165196;
        public static final int save_mem2 = 2131165198;
        public static final int savedmem1 = 2131165193;
        public static final int savedmem2 = 2131165194;
        public static final int textView1 = 2131165185;
        public static final int textView2 = 2131165184;
        public static final int textView3 = 2131165186;
        public static final int textView4 = 2131165190;
        public static final int title_new_devices = 2131165201;
        public static final int title_paired_devices = 2131165199;
        public static final int xview = 2131165187;
        public static final int yview = 2131165188;
        public static final int zview = 2131165189;
    }

    /* renamed from: robotspace.simplelabs.amr_voice.R.layout */
    public static final class layout {
        public static final int activity_accelerometer_control = 2130903040;
        public static final int activity_app_info = 2130903041;
        public static final int activity_main = 2130903042;
        public static final int activity_splash_screen = 2130903043;
        public static final int device_list = 2130903044;
        public static final int device_name = 2130903045;
        public static final int voice = 2130903046;
    }

    /* renamed from: robotspace.simplelabs.amr_voice.R.menu */
    public static final class menu {
        public static final int activity_splash_screen = 2131099648;
    }

    /* renamed from: robotspace.simplelabs.amr_voice.R.string */
    public static final class string {
        public static final int BtSettings = 2130968580;
        public static final int Scan = 2130968579;
        public static final int app_info = 2130968594;
        public static final int app_name = 2130968576;
        public static final int bt_preference = 2130968590;
        public static final int button_scan = 2130968587;
        public static final int button_setdefault = 2130968592;
        public static final int connection_preference = 2130968591;
        public static final int default_device = 2130968589;
        public static final int hello_world = 2130968577;
        public static final int menu_settings = 2130968578;
        public static final int none_found = 2130968584;
        public static final int none_paired = 2130968583;
        public static final int preferences_activity = 2130968588;
        public static final int scanning = 2130968581;
        public static final int screen_orientation = 2130968593;
        public static final int select_device = 2130968582;
        public static final int title_other_devices = 2130968586;
        public static final int title_paired_devices = 2130968585;
        public static final int f2x = 2130968598;
        public static final int x_axis = 2130968595;
        public static final int y_axis = 2130968596;
        public static final int z_axis = 2130968597;
    }

    /* renamed from: robotspace.simplelabs.amr_voice.R.style */
    public static final class style {
        public static final int AppBaseTheme = 2131034112;
        public static final int AppTheme = 2131034113;
    }
}
