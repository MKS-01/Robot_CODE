package robotspace.simplelabs.amr_voice;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class BtService extends Service {
    private static final boolean f1D = true;
    private static final UUID MY_UUID_SECURE;
    private static final String NAME_SECURE = "BluetoothBTSecure";
    public static final int STATE_CONNECTED = 3;
    public static final int STATE_CONNECTING = 2;
    public static final int STATE_LISTEN = 1;
    public static final int STATE_NONE = 0;
    private static final String TAG = "BtService";
    private final BluetoothAdapter mAdapter;
    private ConnectThread mConnectThread;
    private ConnectedThread mConnectedThread;
    private final Handler mHandler;
    private AcceptThread mSecureAcceptThread;
    private int mState;

    private class AcceptThread extends Thread {
        private String mSocketType;
        private final BluetoothServerSocket mmServerSocket;

        public AcceptThread(boolean secure) {
            BluetoothServerSocket tmp = null;
            this.mSocketType = "Secure";
            if (secure) {
                try {
                    tmp = BtService.this.mAdapter.listenUsingRfcommWithServiceRecord(BtService.NAME_SECURE, BtService.MY_UUID_SECURE);
                } catch (IOException e) {
                    Log.e(BtService.TAG, "Socket Type: " + this.mSocketType + "listen() failed", e);
                }
            }
            this.mmServerSocket = tmp;
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void run() {
            /*
            r6 = this;
            r2 = "BtService";
            r3 = new java.lang.StringBuilder;
            r4 = "Socket Type: ";
            r3.<init>(r4);
            r4 = r6.mSocketType;
            r3 = r3.append(r4);
            r4 = "BEGIN mAcceptThread";
            r3 = r3.append(r4);
            r3 = r3.append(r6);
            r3 = r3.toString();
            android.util.Log.d(r2, r3);
            r2 = new java.lang.StringBuilder;
            r3 = "AcceptThread";
            r2.<init>(r3);
            r3 = r6.mSocketType;
            r2 = r2.append(r3);
            r2 = r2.toString();
            r6.setName(r2);
            r1 = 0;
        L_0x0035:
            r2 = robotspace.simplelabs.amr_voice.BtService.this;
            r2 = r2.mState;
            r3 = 3;
            if (r2 != r3) goto L_0x0055;
        L_0x003e:
            r2 = "BtService";
            r3 = new java.lang.StringBuilder;
            r4 = "END mAcceptThread, socket Type: ";
            r3.<init>(r4);
            r4 = r6.mSocketType;
            r3 = r3.append(r4);
            r3 = r3.toString();
            android.util.Log.i(r2, r3);
            return;
        L_0x0055:
            r2 = r6.mmServerSocket;	 Catch:{ IOException -> 0x006e }
            r1 = r2.accept();	 Catch:{ IOException -> 0x006e }
            if (r1 == 0) goto L_0x0035;
        L_0x005d:
            r3 = robotspace.simplelabs.amr_voice.BtService.this;
            monitor-enter(r3);
            r2 = robotspace.simplelabs.amr_voice.BtService.this;	 Catch:{ all -> 0x006b }
            r2 = r2.mState;	 Catch:{ all -> 0x006b }
            switch(r2) {
                case 0: goto L_0x0098;
                case 1: goto L_0x008c;
                case 2: goto L_0x008c;
                case 3: goto L_0x0098;
                default: goto L_0x0069;
            };	 Catch:{ all -> 0x006b }
        L_0x0069:
            monitor-exit(r3);	 Catch:{ all -> 0x006b }
            goto L_0x0035;
        L_0x006b:
            r2 = move-exception;
            monitor-exit(r3);	 Catch:{ all -> 0x006b }
            throw r2;
        L_0x006e:
            r0 = move-exception;
            r2 = "BtService";
            r3 = new java.lang.StringBuilder;
            r4 = "Socket Type: ";
            r3.<init>(r4);
            r4 = r6.mSocketType;
            r3 = r3.append(r4);
            r4 = "accept() failed";
            r3 = r3.append(r4);
            r3 = r3.toString();
            android.util.Log.e(r2, r3, r0);
            goto L_0x003e;
        L_0x008c:
            r2 = robotspace.simplelabs.amr_voice.BtService.this;	 Catch:{ all -> 0x006b }
            r4 = r1.getRemoteDevice();	 Catch:{ all -> 0x006b }
            r5 = r6.mSocketType;	 Catch:{ all -> 0x006b }
            r2.connected(r1, r4, r5);	 Catch:{ all -> 0x006b }
            goto L_0x0069;
        L_0x0098:
            r1.close();	 Catch:{ IOException -> 0x009c }
            goto L_0x0069;
        L_0x009c:
            r0 = move-exception;
            r2 = "BtService";
            r4 = "Could not close unwanted socket";
            android.util.Log.e(r2, r4, r0);	 Catch:{ all -> 0x006b }
            goto L_0x0069;
            */
            throw new UnsupportedOperationException("Method not decompiled: robotspace.simplelabs.amr_voice.BtService.AcceptThread.run():void");
        }

        public void cancel() {
            Log.d(BtService.TAG, "Socket Type" + this.mSocketType + "cancel " + this);
            try {
                this.mmServerSocket.close();
            } catch (IOException e) {
                Log.e(BtService.TAG, "Socket Type" + this.mSocketType + "close() of server failed", e);
            }
        }
    }

    private class ConnectThread extends Thread {
        private String mSocketType;
        private final BluetoothDevice mmDevice;
        private final BluetoothSocket mmSocket;

        public ConnectThread(BluetoothDevice device, boolean secure) {
            this.mmDevice = device;
            BluetoothSocket tmp = null;
            this.mSocketType = "Secure";
            if (secure) {
                try {
                    tmp = device.createRfcommSocketToServiceRecord(BtService.MY_UUID_SECURE);
                } catch (IOException e) {
                    Log.e(BtService.TAG, "Socket Type: " + this.mSocketType + "create() failed", e);
                }
            }
            this.mmSocket = tmp;
        }

        public void run() {
            Log.i(BtService.TAG, "BEGIN mConnectThread SocketType:" + this.mSocketType);
            setName("ConnectThread" + this.mSocketType);
            BtService.this.mAdapter.cancelDiscovery();
            try {
                this.mmSocket.connect();
                synchronized (BtService.this) {
                    BtService.this.mConnectThread = null;
                }
                BtService.this.connected(this.mmSocket, this.mmDevice, this.mSocketType);
            } catch (IOException e) {
                try {
                    this.mmSocket.close();
                } catch (IOException e2) {
                    Log.e(BtService.TAG, "unable to close() " + this.mSocketType + " socket during connection failure", e2);
                }
                BtService.this.connectionFailed();
            }
        }

        public void cancel() {
            try {
                this.mmSocket.close();
            } catch (IOException e) {
                Log.e(BtService.TAG, "close() of connect " + this.mSocketType + " socket failed", e);
            }
        }
    }

    private class ConnectedThread extends Thread {
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;
        private final BluetoothSocket mmSocket;

        public ConnectedThread(BluetoothSocket socket, String socketType) {
            Log.d(BtService.TAG, "create ConnectedThread: " + socketType);
            this.mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                Log.e(BtService.TAG, "temp sockets not created", e);
            }
            this.mmInStream = tmpIn;
            this.mmOutStream = tmpOut;
        }

        public void run() {
            Log.i(BtService.TAG, "BEGIN mConnectedThread");
            byte[] buffer = new byte[AccessibilityNodeInfoCompat.ACTION_NEXT_HTML_ELEMENT];
            while (true) {
                try {
                    BtService.this.mHandler.obtainMessage(BtService.STATE_CONNECTING, this.mmInStream.read(buffer), -1, buffer).sendToTarget();
                } catch (IOException e) {
                    Log.e(BtService.TAG, "disconnected", e);
                    BtService.this.connectionLost();
                    BtService.this.start();
                    return;
                }
            }
        }

        public void write(byte[] buffer) {
            try {
                this.mmOutStream.write(buffer);
                BtService.this.mHandler.obtainMessage(BtService.STATE_CONNECTED, -1, -1, buffer).sendToTarget();
            } catch (IOException e) {
                Log.e(BtService.TAG, "Exception during write", e);
            }
        }

        public void cancel() {
            try {
                this.mmSocket.close();
            } catch (IOException e) {
                Log.e(BtService.TAG, "close() of connect socket failed", e);
            }
        }
    }

    static {
        MY_UUID_SECURE = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
    }

    public BtService(Context context, Handler handler) {
        this.mAdapter = BluetoothAdapter.getDefaultAdapter();
        this.mState = STATE_NONE;
        this.mHandler = handler;
    }

    private synchronized void setState(int state) {
        Log.d(TAG, "setState() " + this.mState + " -> " + state);
        this.mState = state;
        this.mHandler.obtainMessage(STATE_LISTEN, state, -1).sendToTarget();
    }

    public synchronized int getState() {
        return this.mState;
    }

    public synchronized void start() {
        Log.d(TAG, "start");
        if (this.mConnectThread != null) {
            this.mConnectThread.cancel();
            this.mConnectThread = null;
        }
        if (this.mConnectedThread != null) {
            this.mConnectedThread.cancel();
            this.mConnectedThread = null;
        }
        setState(STATE_LISTEN);
        if (this.mSecureAcceptThread == null) {
            this.mSecureAcceptThread = new AcceptThread(f1D);
            this.mSecureAcceptThread.start();
        }
    }

    public synchronized void connect(BluetoothDevice device, boolean secure) {
        Log.d(TAG, "connect to: " + device);
        if (this.mState == STATE_CONNECTING && this.mConnectThread != null) {
            this.mConnectThread.cancel();
            this.mConnectThread = null;
        }
        if (this.mConnectedThread != null) {
            this.mConnectedThread.cancel();
            this.mConnectedThread = null;
        }
        this.mConnectThread = new ConnectThread(device, secure);
        this.mConnectThread.start();
        setState(STATE_CONNECTING);
    }

    public synchronized void connected(BluetoothSocket socket, BluetoothDevice device, String socketType) {
        Log.d(TAG, "connected, Socket Type:" + socketType);
        if (this.mConnectThread != null) {
            this.mConnectThread.cancel();
            this.mConnectThread = null;
        }
        if (this.mConnectedThread != null) {
            this.mConnectedThread.cancel();
            this.mConnectedThread = null;
        }
        if (this.mSecureAcceptThread != null) {
            this.mSecureAcceptThread.cancel();
            this.mSecureAcceptThread = null;
        }
        this.mConnectedThread = new ConnectedThread(socket, socketType);
        this.mConnectedThread.start();
        Message msg = this.mHandler.obtainMessage(4);
        Bundle bundle = new Bundle();
        bundle.putString(VoiceControlActivity.DEVICE_NAME, device.getName());
        msg.setData(bundle);
        this.mHandler.sendMessage(msg);
        setState(STATE_CONNECTED);
    }

    public synchronized void stop() {
        Log.d(TAG, "stop");
        if (this.mConnectThread != null) {
            this.mConnectThread.cancel();
            this.mConnectThread = null;
        }
        if (this.mConnectedThread != null) {
            this.mConnectedThread.cancel();
            this.mConnectedThread = null;
        }
        if (this.mSecureAcceptThread != null) {
            this.mSecureAcceptThread.cancel();
            this.mSecureAcceptThread = null;
        }
        setState(STATE_NONE);
    }

    public void write(byte[] out) {
        synchronized (this) {
            if (this.mState != STATE_CONNECTED) {
                return;
            }
            ConnectedThread r = this.mConnectedThread;
            r.write(out);
        }
    }

    private void connectionFailed() {
        Message msg = this.mHandler.obtainMessage(5);
        Bundle bundle = new Bundle();
        bundle.putString(VoiceControlActivity.TOAST, "Unable to connect device");
        msg.setData(bundle);
        this.mHandler.sendMessage(msg);
        start();
    }

    private void connectionLost() {
        Message msg = this.mHandler.obtainMessage(5);
        Bundle bundle = new Bundle();
        bundle.putString(VoiceControlActivity.TOAST, "Device connection was lost");
        msg.setData(bundle);
        this.mHandler.sendMessage(msg);
        start();
    }

    public IBinder onBind(Intent arg0) {
        return null;
    }
}
